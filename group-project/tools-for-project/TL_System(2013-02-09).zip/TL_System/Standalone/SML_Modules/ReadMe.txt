The UserDefined.sml and UserLibrary.cm filenames must be preserved (i.e., cannot be renamed).
The naming of all other files is unrestricted. 